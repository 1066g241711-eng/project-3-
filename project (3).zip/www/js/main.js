let map = L.map('map').setView([34.64416838426136, 135.0475757759303], 1);

L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}' ,{
  attribution: "<a href='https://maps.gsi.go.jp/development/ichiran.html' target='_blank'>地理院タイル</a>"
}).addTo(map);
/*
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
*/

L.marker([46.6464332925712, 7.652389834287852]).addTo(map)
    .bindPopup('<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSORl4e6LmF5IUzYGXoQpaV-LOW37OQSCg08HshlDBeUA&s"class="popup-img">ニーゼン山の階段— 11,674段ギネス記録に認定されている世界で最も段数が多い階段。')
L.marker([36.2559049602439, 117.10556629499655]).addTo(map)
    .bindPopup('<img src="https://upload.wikimedia.org/wikipedia/commons/7/74/%E6%B3%B0%E5%B1%B1_%E5%8D%97%E5%A4%A9%E9%97%A8.jpg?utm_source=ja.wikipedia.org&utm_campaign=index&utm_content=original"class="popup-img">泰山 約7,000段 世界遺産の山頂まで続く巨大な石段。')
L.marker([40.4318995048909, 116.57036416812515]).addTo(map)
    .bindPopup('<img src="https://www.veltra.com/jp/guide/wp-content/uploads/2025/03/hwy9r6_yzgm.jpg"class="popup-img">万里の長城マラソン区間　— 5,164段　城壁沿いに続く膨大なアップダウン。')
L.marker([59.01368953541697, 6.4286547987400455]).addTo(map)
    .bindPopup('<img src="https://cdn.4travel.jp/img/thumbnails/imk/travelogue_pict/48/83/80/650x_48838040.jpg?updated_at=1603697670"class="popup-img">ノルウェーのリーセフィヨルド沿いに位置するフレルリ　— 4,444段　水力発電所のパイプライン沿いにある世界最長の木製階段。')
L.marker([21.396117257475233, -157.82398272482703]).addTo(map)
    .bindPopup('<img src="https://www.cnn.co.jp/storage/2021/09/17/6ad6f5f24b482f66f7edc3a3c6d1cd7c/t/768/432/d/210914224113-haiku-stairs-hawaii-trnd-super-169.jpg"class="popup-img">ハイク・ステアーズ　— 3,922段　ハワイ・オアフ島の山背に続く鉄製の階段。')
L.marker([25.197226101600716, 55.27435493875146]).addTo(map)
    .bindPopup('<img src="https://yakei.jp/abroad/dubai/photo/small/burj_khalifa13.jpg"class="popup-img">ブルジュ・ハリファ　— 2,909段　超高層ビルの非常階段。')
L.marker([40.748456727348135, -73.98567513186133]).addTo(map)
    .bindPopup('<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRE2agLOAEM89c02thGniGupvqjPy04SNhK9JZ80xg-LQ&s=10"class="popup-img">エンパイア・ステート・ビル　— 1,860段　ニューヨークの高層ビル階段駆け上がりレースで有名。')
L.marker([48.85837007133222, 2.294438382006234]).addTo(map)
    .bindPopup('<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkncJmDFPcjLU1xFynXaFNN67_6h764X0DvJQNPfHGAg&s=10"class="popup-img">エッフェル塔　— 1,665段　地上から最頂部まで続く階段。')
L.marker([50.64812787163071, 5.577377197436594]).addTo(map)
    .bindPopup('<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSEMJlCX3Dxd4h_eYWmwqUKLv7mOPRbuTPJkN3YWjcnmTsjZ5qHOGSUx5c&s=10"class="popup-img">モンタニュビューラン　— 374段　市街地にある極めて傾斜が急な有名石段。')
L.marker([29.047032083528993, 110.48208378892977]).addTo(map)
    .bindPopup('<img src="https://cdn.4travel.jp/img/thumbnails/imk/travelogue_album/12/02/81/500x_12028146.jpg?updated_at=1768963872"class="popup-img">天門山「天国への扉」— 999段　巨大な洞窟の穴へ向かって一直線に伸びる急勾配の階段。')
L.marker([32.576505712725826, 130.82226049986912]).addTo(map)
    .bindPopup('<img src="https://static.amanaimages.com/imgroom/rf_preview640/10685/10685004684.jpg"class="popup-img">日本一の石段 / 釈迦院御坂遊歩道　3,333段　日本一の段数を誇る石段。挑戦者も多く、登りきった先の達成感は抜群。')
L.marker([38.70642399230191, 139.96403055361952]).addTo(map)
    .bindPopup('<img src="https://images.www.kateigaho.com/media/article/178138/images/editor/d2c11f86e154457d3636b099bdbe75c0dbd1a245.jpg?d=550x670"class="popup-img">羽黒山 / 出羽三山神社　2,446段　杉並木に囲まれた神秘的な参道。途中に国宝の五重塔がある。')
L.marker([34.97877444767325, 137.58623040005082]).addTo(map)
    .bindPopup('<img src="https://aichinow.pref.aichi.jp/upload/site/spots/retina/456a8d74c6551624e0b84bc7388b04d8.jpg"class="popup-img">鳳来寺　1,425段　奥三河の静かな山寺へ続く石段。自然豊かで心落ち着くコース。')
L.marker([34.18402737058727, 133.80936437923972]).addTo(map)
    .bindPopup('<img src="https://www.photolibrary.jp/mhd1/img609/450-20180629190617268639.jpg"class="popup-img">金刀比羅宮　1,368段　「こんぴらさん」の名で親しまれる参道（本宮まで785段、奥社まで1,368段）。')
L.marker([35.49654380753545, 132.8740010255972]).addTo(map)
    .bindPopup('<img src="https://pds.exblog.jp/pds/1/201203/26/29/a0000029_20263139.jpg"class="popup-img">一畑薬師　約1,300段　「目のお薬師さま」として知られる霊場へと伸びる長い石段。')
L.marker([35.14494969981401, 136.16058181024292]).addTo(map)
    .bindPopup('<img src="https://diiig.net/upload/dc2ca190568fb5085f17c2d2f321e4f0.jpg"class="popup-img">観音正寺　約1,200段　西国三十三所の難所の一つ。登りきると琵琶湖を一望できる絶景が広がる。')
L.marker([34.964843557473145, 138.46757026790638]).addTo(map)
    .bindPopup('<img src="https://www.yomiuri.co.jp/media/2022/04/20220418-OYT8I50012-1.jpg?type=x-large"class="popup-img">久能山東照宮　1,159段　駿河湾を一望しながら登れる、風光明媚で歴史ある参道。')
L.marker([38.31311927185473, 140.43457771036674]).addTo(map)
    .bindPopup('<img src="https://preview.imagemart.jp/AsS2j7EENUWI/afloimagemart_242418567.jpg"class="popup-img">立石寺 / 山寺　1,015段　松尾芭蕉の句「閑さや岩にしみ入る蝉の声」で有名な景勝地。')
L.marker([36.36250478606303, 139.69314817874482]).addTo(map)
    .bindPopup('<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_NqgN2cek16IpDkKzXLsNAMEn3BQ3OjMfe18Z7YebLpmv6Rep2nFjph8v&s=10"class="popup-img">太平山神社 / あじさい坂　約1,000段　初夏には参道沿いに色鮮やかなアジサイが咲き誇る見どころ満載の坂。')
L.marker([39.87061381913496, 139.75089323798542]).addTo(map)
    .bindPopup('<img src="https://www.hometopia.jp/content/uploads/sites/2/2017/01/sendai_20170110_01.jpg"class="popup-img">赤神神社五社堂　999段　「鬼が一夜で積み上げた」という伝説が残る荒々しくも神秘的な石段。')
